var indexSectionsWithContent =
{
  0: "cghpst~с",
  1: "h",
  2: "cghpst~",
  3: "с"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Функции",
  3: "Страницы"
};

